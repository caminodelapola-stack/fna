# Compilación automática APK

Este proyecto incluye `.github/workflows/build-apk.yml`.

Al subirlo a GitHub:
1. Abre la pestaña **Actions**.
2. Entra en **Build Android APK**.
3. Pulsa **Run workflow** si no se ha ejecutado automáticamente.
4. Cuando termine en verde, descarga el artefacto **Amazon-FNAC-SumUp-debug-apk**.
5. Dentro estará `app-debug.apk`.
