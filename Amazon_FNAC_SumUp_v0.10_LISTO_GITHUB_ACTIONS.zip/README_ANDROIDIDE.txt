Amazon FNAC SumUp v0.10 - proyecto AndroidIDE corregido

CORRECCIÓN: se añade el archivo gradlew que faltaba y que provocaba:
  bash: ./gradlew: No such file or directory

Pasos:
1. Descomprime el ZIP.
2. En AndroidIDE abre la carpeta AmazonFnacSumUp (la que contiene app, build.gradle, settings.gradle y gradlew).
3. Pulsa Build/Run otra vez.
4. Si AndroidIDE pide instalar Gradle/SDK, acepta la instalación y reintenta.
5. El APK debug se genera normalmente en app/build/outputs/apk/debug/app-debug.apk.
